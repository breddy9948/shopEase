package com.ecomproj.shopease.entities;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED
}
